Set-Location $PSScriptRoot
$url = "http://127.0.0.1:8080/"
$py = Get-Command py -ErrorAction SilentlyContinue
$python = Get-Command python -ErrorAction SilentlyContinue
if ($py) {
  Start-Process $url
  & py -3 -m http.server 8080
} elseif ($python) {
  Start-Process $url
  & python -m http.server 8080
} else {
  Invoke-Item (Join-Path $PSScriptRoot "index.html")
  Write-Host "Opened index.html (install Python for a local server)."
}
