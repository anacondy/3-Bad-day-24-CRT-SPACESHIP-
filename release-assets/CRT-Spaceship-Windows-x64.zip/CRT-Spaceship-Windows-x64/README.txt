# CRT Spaceship — Windows (portable) package

Version: 1.0.0
License: Apache License 2.0 (see LICENSE and NOTICE)

## Play online (no download needed)

https://anacondy.github.io/3-Bad-day-24-CRT-SPACESHIP-/

## Run this package offline / locally

1. Unzip this folder anywhere (no install).
2. Double-click `Play-CRT-Spaceship.bat`
   — or open a terminal in this folder and run:
     py -3 -m http.server 8080
     (or: python -m http.server 8080)

Then open the URL shown (usually http://localhost:8080/) in your browser.

You can also double-click `index.html` in many browsers. A local HTTP server
is more reliable for Web Audio and optional version.json loading.

## Controls

- **Mouse / touch:** move ship, click/tap to fire
- **Keyboard:** ← → move | Shift fire | Shift+A auto-fire | M mute | Space pause | Enter start

## Contents

- index.html — game (Canvas + Web Audio)
- js/telemetry.js — optional local diagnostics (localStorage only)
- site.webmanifest — Add to Home Screen metadata
- LICENSE / NOTICE — Apache-2.0

No installer, no admin rights, no native binary required.
