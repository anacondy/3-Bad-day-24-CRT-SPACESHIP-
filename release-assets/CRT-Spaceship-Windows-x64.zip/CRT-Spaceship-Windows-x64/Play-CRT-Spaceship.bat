@echo off
setlocal
cd /d "%~dp0"
echo.
echo  CRT Spaceship — starting local server on http://127.0.0.1:8080/
echo  Close this window to stop the server.
echo.

where py >nul 2>&1
if %ERRORLEVEL%==0 (
  start "" "http://127.0.0.1:8080/"
  py -3 -m http.server 8080
  goto :eof
)

where python >nul 2>&1
if %ERRORLEVEL%==0 (
  start "" "http://127.0.0.1:8080/"
  python -m http.server 8080
  goto :eof
)

where py >nul 2>&1
where python >nul 2>&1
echo Python was not found. Opening index.html directly...
start "" "%~dp0index.html"
echo.
echo Tip: Install Python from https://www.python.org/ or open index.html in Chrome/Edge.
pause
