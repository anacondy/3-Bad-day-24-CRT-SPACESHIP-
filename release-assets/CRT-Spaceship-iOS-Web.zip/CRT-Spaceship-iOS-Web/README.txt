CRT Spaceship on iOS / iPadOS
=============================

1. Open Safari (required for Add to Home Screen):
   https://anacondy.github.io/3-Bad-day-24-CRT-SPACESHIP-/

2. Tap Share → Add to Home Screen

3. Launch the icon for a fullscreen-style web app experience

This package contains the same web files for offline/LAN hosting. It is NOT
an App Store IPA. Building a native IPA requires an Apple Developer account,
Xcode, and code signing — out of scope for this HTML5 game release.
