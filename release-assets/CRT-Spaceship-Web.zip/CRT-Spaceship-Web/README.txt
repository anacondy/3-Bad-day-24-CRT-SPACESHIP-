# CRT Spaceship — Web package (all platforms)

Version: 1.0.0
License: Apache License 2.0

This archive is the complete game. Host it on any static file server, or open
index.html locally.

## Android

1. Prefer the live site: https://anacondy.github.io/3-Bad-day-24-CRT-SPACESHIP-/
2. Chrome menu → "Add to Home screen" / "Install app"
3. Or host this folder on your LAN and open it in Chrome

There is no signed Play Store APK in this release (would require Android SDK
signing keys). A Trusted Web Activity (TWA) is optional for store packaging;
see packaging/android/ in the source repo.

## iOS / iPadOS

1. Open https://anacondy.github.io/3-Bad-day-24-CRT-SPACESHIP-/ in Safari
2. Share → Add to Home Screen
3. No App Store IPA is provided (Apple signing + developer account required)

## Desktop

Use the Windows / macOS / Linux archives for convenience launchers, or serve
this folder with any static server.
