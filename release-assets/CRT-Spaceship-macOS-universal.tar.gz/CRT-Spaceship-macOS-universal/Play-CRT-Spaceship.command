#!/bin/bash
cd "$(dirname "$0")"
echo ""
echo " CRT Spaceship — http://127.0.0.1:8080/"
echo " Close this window or press Ctrl+C to stop."
echo ""
open "http://127.0.0.1:8080/" 2>/dev/null || true
if command -v python3 >/dev/null 2>&1; then
  exec python3 -m http.server 8080
elif command -v python >/dev/null 2>&1; then
  exec python -m http.server 8080
else
  open "index.html"
  echo "Python not found; opened index.html directly."
  read -r -p "Press Enter to close..."
fi
