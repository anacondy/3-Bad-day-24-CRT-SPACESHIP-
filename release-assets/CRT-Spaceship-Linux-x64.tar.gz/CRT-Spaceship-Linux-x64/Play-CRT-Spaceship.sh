#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$(readlink -f "$0" 2>/dev/null || realpath "$0" 2>/dev/null || echo "$0")")"
PORT="${PORT:-8080}"
URL="http://127.0.0.1:${PORT}/"
echo ""
echo " CRT Spaceship — ${URL}"
echo " Press Ctrl+C to stop the server."
echo ""
# Best-effort browser open
if command -v xdg-open >/dev/null 2>&1; then
  (sleep 0.4; xdg-open "${URL}") >/dev/null 2>&1 &
elif command -v sensible-browser >/dev/null 2>&1; then
  (sleep 0.4; sensible-browser "${URL}") >/dev/null 2>&1 &
fi
if command -v python3 >/dev/null 2>&1; then
  exec python3 -m http.server "${PORT}" --bind 127.0.0.1
elif command -v python >/dev/null 2>&1; then
  exec python -m http.server "${PORT}" --bind 127.0.0.1
else
  echo "python3 not found. Open index.html in a browser:"
  echo "  ${PWD}/index.html"
  exit 1
fi
